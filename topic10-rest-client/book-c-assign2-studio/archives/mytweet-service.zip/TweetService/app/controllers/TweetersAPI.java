package controllers;

import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonElement;

import models.Tweet;
import models.Tweeter;
import play.mvc.Controller;

public class TweetersAPI extends Controller
{
  static Gson gson = new Gson();

  public static void getAllTweeters()
  {
    List<Tweeter> Tweeters = Tweeter.findAll();
    renderJSON(gson.toJson(Tweeters));
  }

  public static void getTweeter(String id)
  {
    Tweeter tweeter = Tweeter.findById(id);
    if (tweeter == null)
    {
      notFound();
    }
    else
    {
      renderJSON(gson.toJson(tweeter));
    }
  }

  public static void createTweeter(JsonElement body)
  {
    Tweeter tweeter = gson.fromJson(body.toString(), Tweeter.class);
    tweeter.save();
    renderJSON(gson.toJson(tweeter));
  }

  /**
   * Search for Tweeter corresponding to email-password in currTweeter
   * If found, this means currTweeter is registered: return copy registered tweeter.
   * Else return currTweeter
   * 
   * @param body : a partially initialized Tweeter object (email & pwd only)
   * 
   */
  public static void login(JsonElement body)
  {
    Tweeter currTweeter = gson.fromJson(body.toString(), Tweeter.class);
    List<Tweeter> tweeters = Tweeter.findAll();
    for (Tweeter tweeter : tweeters)
    {
      if (tweeter.email.equalsIgnoreCase(currTweeter.email))
      {
        renderJSON(gson.toJson(tweeter)); 
      }
     }
    renderJSON(gson.toJson(currTweeter));

  }

  public static void deleteTweeter(String id)
  {
    Tweeter tweeter = Tweeter.findById(id);
    if (tweeter == null)
    {
      notFound("No Tweeter with ID" + id);
    }
    else
    {
      tweeter.delete();
      renderJSON(gson.toJson(tweeter));
    }
  }

  public static void deleteAllTweeters()
  {
    Tweeter.deleteAll();
    renderText("success");
  }
}