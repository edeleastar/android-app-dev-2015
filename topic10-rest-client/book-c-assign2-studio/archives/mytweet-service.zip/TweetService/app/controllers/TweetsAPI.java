package controllers;

import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonElement;

import models.Tweet;
import models.Tweeter;
import play.mvc.Controller;

public class TweetsAPI extends Controller
{
  static Gson gson = new Gson();

  public static void createTweet(JsonElement body)
  {
    Tweet tweet = gson.fromJson(body.toString(), Tweet.class);
    tweet.save();
    renderJSON(gson.toJson(tweet));
  }

  public static void getAllTweets()
  {
    List<Tweet> tweets = Tweet.findAll();
    renderJSON(gson.toJson(tweets));
  }
  
//  public static void getTweets(String id)
//  {
//    Tweet tweet = Tweet.findById(id);
//    renderJSON(gson.toJson(tweet));
//  }
  
//  public static void getTweet(String id)
//  {
//    Tweet tweet = Tweet.findById(id);  
//    if (tweet == null)
//    {
//      notFound();
//    }
//    else
//    {
//      renderJSON(gson.toJson(tweet));
//    }
//  }
 
  public static void getTweet (String id, String tweetId)
  {
   Tweet tweet = Tweet.findById(tweetId);
   if (tweet == null)
   {
     notFound();
   }
   else
   {
     renderJSON(gson.toJson(tweet));
   }
  }
  
  /*
   * TODO: why param 1?
   */
  public static void deleteTweet(String id, String tweetId)
  {
    Tweet tweet = Tweet.findById(tweetId);
    if (tweet == null)
    {
      notFound();
    }
    else
    {
      tweet.delete();
      renderText("success");
    }
  }
  
  public static void deleteAllTweets()
  {
    Tweet.deleteAll();
    renderText("success");
  }  
}