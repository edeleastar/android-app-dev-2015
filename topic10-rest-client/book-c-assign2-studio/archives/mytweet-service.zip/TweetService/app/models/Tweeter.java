package models;

import javax.persistence.Entity;
import javax.persistence.Id;
import play.db.jpa.GenericModel;
import javax.persistence.GeneratedValue;
@Entity
public class Tweeter extends GenericModel
{
  @Id
  public String id;
  public String firstName;
  public String lastName;
  public String email;
  public String password;

  /**
   * A copy constructor
   * @param other
   */
  public Tweeter(Tweeter other)
  {
    this.id = other.id;
    this.firstName = other.firstName;
    this.lastName = other.lastName;
    this.email = other.email;
    this.password = other.password;
  }
  
  public static Tweeter findByEmail(String email)
  {
    return find("email", email).first();
  }

  public boolean checkPassword(String password)
  {
    return this.password.equals(password);
  }

  public String getFullName()
  {
    return firstName + " " + lastName;
  }
}