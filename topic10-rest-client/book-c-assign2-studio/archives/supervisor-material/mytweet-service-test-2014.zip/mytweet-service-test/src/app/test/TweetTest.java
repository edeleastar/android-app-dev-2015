package app.test;

import static org.junit.Assert.assertEquals;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;

import app.api.MyTweetServiceAPI;
import app.model.Tweet;

public class TweetTest
{
  @Test
  public void testCreate() throws Exception
  {
    Tweet tweetTxd = new Tweet("first tweet", "17-Nov-2014 12:45:53");
    //TODO create tweet on server and echo back as Tweet tweetRxd
    //TODO: assertEquals(tweetTxd.getId(), tweetRxd.getId());
  }

@Test 
  public void testCreateTweets() throws Exception
  {
    int nmr_tweets = 10;
    for(int i=0; i < nmr_tweets; i += 1)
    {
      String message = RandomStringUtils.randomAlphabetic(new Random().nextInt(10) + 20);//message word range 10 to 30
      String date = DateFormat.getDateTimeInstance().format(new Date());
      Tweet tweetTxd = new Tweet(message, date);
      
      //TODO: create tweet on server and echo back as Tweet tweetRxd
      
      //TODO assertEquals(tweetTxd.uuid, tweetRxd.uuid);
    }
  }
 
 @Test
 public void getTweets()
 {
   //TODO get all tweets
   //TODO display all tweets
 }
 
 @Test
 public void deleteAllIndividually() throws Exception
 {
   List<Tweet> tweets = new ArrayList<Tweet>();//TODO: Replace with statement to retrieve all tweets
   for(Tweet tweet : tweets)
   {
    //TODO delete each tweet individually
   }
 }
 
  
 @Test
 public void deleteAll() throws Exception
 {
   //TODO
 }
}