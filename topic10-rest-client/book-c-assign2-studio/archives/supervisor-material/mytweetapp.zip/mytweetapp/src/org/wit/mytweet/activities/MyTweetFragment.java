package org.wit.mytweet.activities;

import static org.wit.android.helpers.IntentHelper.navigateUp;

import java.util.List;
import java.util.UUID;

import org.wit.android.helpers.LogHelpers;
import org.wit.mytweet.app.MyTweetApp;
import org.wit.mytweet.http.Response;
import org.wit.mytweet.model.MyTweetServiceAPI;
import org.wit.mytweet.model.Tweet;
import org.wit.mytweet.model.TweetList;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.wit.mytweet.R;

public class MyTweetFragment extends Fragment implements TextWatcher, OnClickListener, Response<Tweet>
{
  public static final String EXTRA_TWEET_ID = "tweeter.TWEET_ID";
  public static final int MAX_CHARS_ALLOWED = 140;
  
  private EditText tweet_message;
  private TextView tweet_count;
  private Button tweet_button;
  private Tweet this_tweet;
  private TweetList tweetlist;

  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setHasOptionsMenu(true);
    
    
    UUID tweId = (UUID) getArguments().getSerializable(EXTRA_TWEET_ID);

    MyTweetApp app = (MyTweetApp) getActivity().getApplication();
    tweetlist = app.tweetlist;
    this_tweet = tweetlist.getTweet(tweId);
  }

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState)
  {
    View v = inflater.inflate(R.layout.fragment_my_tweet, parent, false);

    getActivity().getActionBar().setDisplayHomeAsUpEnabled(true);
    
    addListeners(v);
    return v;
  }

  private void addListeners(View v)
  {
    tweet_message = (EditText) v.findViewById(R.id.tweet_message);
    tweet_count   = (TextView) v.findViewById(R.id.tweet_count);
    tweet_button  = (Button) v.findViewById(R.id.tweet_button);
    
    tweet_message.setText(this_tweet.message);
    setCounterTextColor(this_tweet.message);
    tweet_count.setText(Integer.toString(MAX_CHARS_ALLOWED - this_tweet.message.length()));
    tweet_message.addTextChangedListener(this);
    tweet_button.setOnClickListener(this);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item)
  {
    switch (item.getItemId())
    {
    case android.R.id.home:
      navigateUp(getActivity());
      return true;

    case R.id.action_settings:
      startActivity(new Intent(getActivity(), SettingsActivity.class));
      return true;

    default:
      return super.onOptionsItemSelected(item);
    }
  }

  public void onPause()
  {
    super.onPause();
    tweetlist.saveTweets();
  }

  private void setCounterTextColor(String msg)
  {
    int chars_remaining = MAX_CHARS_ALLOWED - msg.length();
    tweet_count.setText(Integer.toString(chars_remaining));
    if (chars_remaining > MAX_CHARS_ALLOWED/2)
    {
      tweet_count.setTextColor(Color.GREEN);
    }
    else if(chars_remaining > 10 )
    {
      tweet_count.setTextColor(Color.CYAN);
    }
    else 
    {
      tweet_count.setTextColor(Color.RED);
    }
  }
  //------------textwatcher methods-------------------------------------------------
  @Override
  public void beforeTextChanged(CharSequence s, int start, int count, int after)
  {
  }

  @Override
  public void onTextChanged(CharSequence msg, int start, int before, int count)
  {
    setCounterTextColor(msg.toString());
  }

  @Override
  public void afterTextChanged(Editable message)
  {
    //update model
    this_tweet.message = message.toString();
    LogHelpers.info(this, message.toString());
    
  }
//------------textwatcher methods end --------------------------------------------
  
  public void onClick(View v)
  {
    switch (v.getId())
    {
      case R.id.tweet_button:
        MyTweetServiceAPI.createTweet(getActivity(), this, "tweeting", this_tweet);

        break;
    }
  }

  @Override
  public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
  {
    super.onCreateOptionsMenu(menu, inflater);
    inflater.inflate(R.menu.my_tweet, menu);
  }

  @Override
  public void setResponse(List<Tweet> aList)
  {
  }

  @Override
  public void setResponse(Tweet anObject)
  {
    Toast toast = Toast.makeText(getActivity(), "Message Sent", Toast.LENGTH_SHORT);
    toast.show();  
  }

  @Override
  public void errorOccurred(Exception e)
  {
    Toast toast = Toast.makeText(getActivity(), "Tweeting failed", Toast.LENGTH_SHORT);
    toast.show();    
  }
}