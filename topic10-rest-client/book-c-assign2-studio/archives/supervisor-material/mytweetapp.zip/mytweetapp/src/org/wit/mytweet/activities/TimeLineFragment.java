package org.wit.mytweet.activities;

import java.util.ArrayList;
import java.util.List;

import org.wit.android.helpers.IntentHelper;
import org.wit.android.helpers.LogHelpers;
import org.wit.mytweet.app.MyTweetApp;
import org.wit.mytweet.http.Response;
import org.wit.mytweet.model.MyTweetServiceAPI;
import org.wit.mytweet.model.Tweet;
import org.wit.mytweet.model.TweetList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.MultiChoiceModeListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.wit.mytweet.R;

public class TimeLineFragment extends ListFragment implements OnItemClickListener, MultiChoiceModeListener, Response<Tweet>

{
  private ArrayList<Tweet> tweets;
  private TweetList tweetlist;
  private TweetAdapter adapter;
  private ListView listView;

  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setHasOptionsMenu(true);
    getActivity().setTitle(R.string.app_name);

    MyTweetApp app = (MyTweetApp) getActivity().getApplication();
    tweetlist = app.tweetlist;
    tweets = tweetlist.tweets;

    adapter = new TweetAdapter(getActivity(), tweets);
    setListAdapter(adapter);
  }

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState)
  {
    View v = super.onCreateView(inflater, parent, savedInstanceState);
    listView = (ListView) v.findViewById(android.R.id.list);
    listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
    listView.setMultiChoiceModeListener(this);

    return v;
  }

  @Override
  public void onListItemClick(ListView l, View v, int position, long id)
  {
    Tweet tweet = ((TweetAdapter) getListAdapter()).getItem(position);
    Intent i = new Intent(getActivity(), MyTweetPagerActivity.class);
    i.putExtra(MyTweetFragment.EXTRA_TWEET_ID, tweet.getId());
    startActivityForResult(i, 0);
  }

  @Override
  public void onResume()
  {
    super.onResume();
    adapter.notifyDataSetChanged();
/*    for (Tweet t : tweets)
    {
      if (t.message == null || t.message.equals(""))
      {
        tweets.remove(t);
      }
    }
    tweetlist.saveTweets();
    adapter.notifyDataSetChanged();*/
  }

  @Override
  public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
  {
    super.onCreateOptionsMenu(menu, inflater);
    inflater.inflate(R.menu.time_line, menu);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item)
  {
    switch (item.getItemId())
    {
    case R.id.action_settings:
      startActivity(new Intent(getActivity(), SettingsActivity.class));
      return true;

    case R.id.menuTweet:
      Tweet tweet = new Tweet();
      tweetlist.addTweet(tweet);

      Intent i = new Intent(getActivity(), MyTweetPagerActivity.class);
      i.putExtra(MyTweetFragment.EXTRA_TWEET_ID, tweet.getId());
      startActivityForResult(i, 0);
      return true;

    case R.id.menuClear:
      removeTweets();
      return true;

    default:
      return super.onOptionsItemSelected(item);
    }
  }

  @Override
  public void onItemClick(AdapterView<?> parent, View view, int position, long id)
  {
    Tweet tweet = adapter.getItem(position);
    IntentHelper.startActivityWithData(getActivity(), MyTweetPagerActivity.class, "TWEET_ID", tweet.getId());
  }

  class TweetAdapter extends ArrayAdapter<Tweet>
  {
    private Context context;

    public TweetAdapter(Context context, ArrayList<Tweet> tweets)
    {
      super(context, 0, tweets);
      this.context = context;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
      LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
      if (convertView == null)
      {
        convertView = inflater.inflate(R.layout.row_tweet, null);
      }
      Tweet twe = getItem(position);

      TextView tweet = (TextView) convertView.findViewById(R.id.tweet_list_item_message);
      tweet.setText(twe.message);

      TextView dateTextView = (TextView) convertView.findViewById(R.id.tweet_list_item_dateTextView);
      dateTextView.setText(twe.getDateString());

      return convertView;
    }
  }
  /* ************ MultiChoiceModeListener methods (begin) *********** */
  public boolean onCreateActionMode(ActionMode mode, Menu menu)
  {
    MenuInflater inflater = mode.getMenuInflater();
    inflater.inflate(R.menu.tweet_list_item_context, menu);
    return true;
  }

  public boolean onPrepareActionMode(ActionMode mode, Menu menu)
  {
    return false;
  }

  public boolean onActionItemClicked(ActionMode mode, MenuItem item)
  {
    switch (item.getItemId())
    {
    case R.id.menu_item_delete_tweet:
      removeTweet(mode);
      return true;
    default:
      return false;
    }
  }

  private void removeTweet(ActionMode mode)
  {
    for (int i = adapter.getCount() - 1; i >= 0; i--)
    {
      if (listView.isItemChecked(i))
      {
        Tweet tweet = adapter.getItem(i);
        tweetlist.removeTweet(tweet);
        MyTweetServiceAPI.deleteTweet(getActivity(), this, "deleting tweet", tweet);
      }
    }
    mode.finish();
    tweetlist.saveTweets();
    adapter.notifyDataSetChanged();
  }

  public void onDestroyActionMode(ActionMode mode)
  {
  }

  public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked)
  {
  }
  /* ************ MultiChoiceModeListener methods (end) *********** */  
  private void removeTweets()
  {
    for (int i = adapter.getCount() - 1; i >= 0; i--)
    {
      Tweet tweet = adapter.getItem(i);
      tweetlist.removeTweet(tweet);
      MyTweetServiceAPI.deleteTweet(getActivity(), this, "deleting tweet", tweet);
    }
    tweetlist.saveTweets();
    adapter.notifyDataSetChanged();
  }

  @Override
  public void setResponse(List<Tweet> aList)
  {
  }

  @Override
  public void setResponse(Tweet anObject)
  {
    String msg = "tweet deletion success";
    Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();  
    LogHelpers.info(this, msg);
  }

  @Override
  public void errorOccurred(Exception e)
  {
    String msg = "tweet deletion failure";
    Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();  
    LogHelpers.info(this, msg + " : " + e.getMessage());
  }
}