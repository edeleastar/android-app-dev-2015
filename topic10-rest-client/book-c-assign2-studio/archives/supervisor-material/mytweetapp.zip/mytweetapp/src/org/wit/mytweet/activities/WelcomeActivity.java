package org.wit.mytweet.activities;

import java.util.List;

import org.wit.mytweet.app.MyTweetApp;
import org.wit.mytweet.http.Response;
import org.wit.mytweet.model.MyTweetServiceAPI;
import org.wit.mytweet.model.Tweet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import org.wit.mytweet.R;

public class WelcomeActivity extends Activity implements Response<Tweet>, OnClickListener
{

  Button switchTimeline;
  
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_welcome);
   
   switchTimeline = (Button) findViewById(R.id.button_switch_timeline);
   switchTimeline.setEnabled(false);
   switchTimeline.setOnClickListener(this);
  }

  /**
   * Make the server call to retrieve tweets in onResume
   */
  @Override
  protected void onResume()
  {
    MyTweetServiceAPI.getTweets(this, this, "retrieving tweets");
    super.onResume();
  }

  /**
   * Following 3 methods implementations required by Response<T> interface
   */
  @Override
  public void setResponse(List<Tweet> aList)
  { 
    //tweets successfully retrieved from server
    MyTweetApp app = (MyTweetApp) getApplication();
    app.tweetlist.updateTweets(aList);
    Toast.makeText(this, "tweets retrieved", Toast.LENGTH_SHORT).show();    
    switchTimeline.setEnabled(true);    
  }

  @Override
  public void setResponse(Tweet anObject)
  {
  }

  @Override
  public void errorOccurred(Exception e)
  {
    //failed to retrieve tweets
    Toast.makeText(this, "retrieval failed", Toast.LENGTH_LONG).show();    
  }
  
  /**
   * OnClickListener method implementation
   * switchTimeLine button enabled only on successful retrieval of tweets 
   * click button switches to tweet list view
   */
  @Override
  public void onClick(View v)
  {
    switch (v.getId())
    {
      case R.id.button_switch_timeline:
      Intent i = new Intent(this, TimeLineActivity.class);
      startActivity(i);
    }
  }
}
