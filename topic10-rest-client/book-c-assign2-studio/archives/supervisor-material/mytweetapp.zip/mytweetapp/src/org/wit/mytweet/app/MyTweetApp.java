package org.wit.mytweet.app;

import org.wit.mytweet.model.TweetList;
import org.wit.mytweet.model.TweetListSerializer;

import static org.wit.android.helpers.LogHelpers.info;
import android.app.Application;

public class MyTweetApp extends Application
{
  public TweetList tweetlist;
  private static final String FILENAME = "tweetlist.json";

  public void onCreate()
  {
    super.onCreate();
    TweetListSerializer serializer = new TweetListSerializer(this, FILENAME);
    tweetlist = new TweetList(serializer);

    info(this, "TweetControl app launched");
  }
}
