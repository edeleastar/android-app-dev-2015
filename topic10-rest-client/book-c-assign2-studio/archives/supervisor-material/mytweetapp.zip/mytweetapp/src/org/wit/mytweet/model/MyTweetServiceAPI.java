package org.wit.mytweet.model;

import java.util.List;

import org.wit.mytweet.http.Request;
import org.wit.mytweet.http.Response;
import org.wit.mytweet.http.Rest;
import org.wit.mytweet.httputils.JsonParsers;

import android.content.Context;

public class MyTweetServiceAPI
{ 
  public static void getTweets(Context context, Response<Tweet> response, String dialogMesssage)
  {
    new GetTweets(context, response, dialogMesssage).execute();
  }
  
  public static void createTweet(Context context, Response<Tweet> response, String dialogMesssage, Tweet tweet)
  {
    new CreateTweet(context, response, dialogMesssage).execute(tweet);
  }
  
  public static void deleteTweet(Context context, Response<Tweet> response, String dialogMesssage, Tweet tweet)
  {
    new DeleteTweet(context, response, dialogMesssage).execute(tweet);
  }
}
/*================================================================================*/
class GetTweets extends Request
{
  public GetTweets(Context context, Response<Tweet> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected List<Tweet> doRequest(Object... params) throws Exception
  {
    String response =  Rest.get("/api/tweets");
    List<Tweet> tweetList = JsonParsers.json2Tweets(response);
    return tweetList;
  }
}
 
class CreateTweet extends Request
{
  public CreateTweet(Context context, Response<Tweet> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected Tweet doRequest(Object... params) throws Exception
  {
    String response = Rest.post ("/api/tweets", JsonParsers.tweet2Json(params[0]));
    return JsonParsers.json2Tweet(response);
  }
}

class DeleteTweet extends Request 
{
  public DeleteTweet(Context context, Response<Tweet> callback, String message)
  {
    super(context, callback, message);
  }
  
  @Override 
  protected Tweet doRequest(Object... params) throws Exception

  {
    String id = ((Tweet)params[0]).getId().toString();
    String path = "/api/tweets/" + id; 
    String response = Rest.delete (path);
    if(response.equals("success"))
    {
      return new Tweet();
    }
    else
    {
      throw new Exception();
    }
  }
}
