package controllers;

import java.util.List;
import java.util.Random;

import models.Tweet;
import play.Logger;
import play.mvc.Controller;
import utils.JsonParsers;

import com.google.gson.JsonElement;

public class MyYambaServiceAPI extends Controller
{
  public static void tweets()
  {
    List<Tweet> tweets = Tweet.findAll();
    renderJSON(JsonParsers.tweet2Json(tweets));
  }
  
  public static void tweet(Long id)
  {
    Tweet tweet = Tweet.findById(id);  
    if (tweet == null)
    {
      notFound();
    }
    else
    {
      renderJSON(JsonParsers.tweet2Json(tweet));
    }
  }
  
  public static void createTweet(JsonElement body)
  {
    Tweet tweet = JsonParsers.json2Tweet(body.toString());
    tweet.save();
    renderJSON(JsonParsers.tweet2Json(tweet));
  }
  
  public static void deleteTweet(long id)
  {
    Tweet tweet = Tweet.findById(id);
    if (tweet == null)
    {
      notFound();
    }
    else
    {
      tweet.delete();
      renderText("success");
    }
  }
  
  public static void deleteAllTweets()
  {
    Tweet.deleteAll();
    renderText("success");
  }  
}