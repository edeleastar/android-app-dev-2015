package models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import play.db.jpa.Model;

@Entity
public class Tweet extends Model
{
  @Column(name="userd")//user a reserved PostgreSql word
  public String user;
  public String message;
  public String datestamp;

  public Tweet(String user, String message, String datestamp)
  {
    this.user = user;
    this.message = message;
    this.datestamp = datestamp;
  }
}
