package utils;

import java.lang.reflect.Type;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import models.Tweet;

public class JsonParsers
{
  static Gson gson = new Gson();
  
  public static Tweet json2Tweet(String json)
  {
    return gson.fromJson(json, Tweet.class);   
  }
  
  public static List<Tweet> json2Tweets(String json)
  {
    Type collectionType = new TypeToken<List<Tweet>>() {}.getType();
    return gson.fromJson(json, collectionType); 
  }
  
  public static String tweet2Json(Object obj)
  {
    return gson.toJson(obj);
  }    
}
