package app.test;

import static org.junit.Assert.*;
import java.util.List;
import org.junit.Test;
import app.main.TweetServiceAPI;
import app.models.Tweet;
import app.models.Tweeter;


public class TweetTest
{
  private static TweetServiceAPI service = new TweetServiceAPI();

  @Test
  public void test() throws Exception
  {

    Tweet tweet = new Tweet("tweet-3", "3", "November 16th 10.00 hours");
    Tweet returnedTweet = service.createTweet(tweet.id, tweet);
    assertEquals(tweet, returnedTweet);
   
  }

}
