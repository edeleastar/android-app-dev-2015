package settings.sharedprefs.settings;

import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.util.Log;
import settings.sharedprefs.R;
import settings.sharedprefs.utils.NumUtil;

public class SettingsFragment extends PreferenceFragment implements OnSharedPreferenceChangeListener
{
  private String tag = "MySharedPrefs";
  private SharedPreferences prefs;

  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    addPreferencesFromResource(R.xml.settings);
    setHasOptionsMenu(true);
  }

  @Override
  public void onStart()
  {
    super.onStart();
    prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
    prefs.registerOnSharedPreferenceChangeListener(this);
  }

  @Override
  public void onStop()
  {
    super.onStop();
    prefs.unregisterOnSharedPreferenceChangeListener(this);
  }

  /**
   * @see http://developer.android.com/reference/android/content/SharedPreferences.Editor.html
   * @see http://developer.android.com/reference/android/content/SharedPreferences.html
   * @param sharedPreferences
   * @param key
   */
  @Override
  public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key)
  {
    // Test the Refresh setting
    String DEFAULT = "15";
    long interval = 15;
    String value = sharedPreferences.getString(key, DEFAULT);
    if (NumUtil.isPositiveNumber(value))
    {
      interval = Long.parseLong(value);
    }
    Log.i(tag, "Shared Preference: " + key + " : " + interval);

  }


}
